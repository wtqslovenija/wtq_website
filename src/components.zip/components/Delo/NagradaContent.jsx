export const NagradaItems = [
  {
    title: "",
    text: "The people you invite are your level 1 members, the people your level 1 members invite are your level 2 members, and the people your level 2 members invite are your level 3 members. You can get invitation rewards for up to three-level members to activate their accounts.",
  },
  {
    title: "",
    text: "Your account is a LV2 level account. You have invited friend A to activate the LV2 level account. You can get 40.8 USDT as an invitation reward, and friend A will become your level 1 member. When your level 1 member invites friend B to activate the LV2 level account, you can get a 27.2 USDT invitation reward, and friend B will become your level 2 member. When your level 2 member invites friend C to activate the LV2 account, you can get a 13.6 USDT invitation reward, and friend C will become your level 3 member. You can get invitation rewards for up to three-level members to activate their accounts.The more people you invite or the more people your Level 1 and Level 2 members invite, the more invitation rewards you will get, without limit.",
  },
  {
    title: "",
    text: "Recipients of invitation rewards cannot receive invitation rewards exceeding their LV level. (Example: You are LV1, and the person you invite has activated LV2, you can only get the invitation reward of LV1)",
  },
  {
    title: "",
    text: "The people you invite are your level 1 members, the people your level 1 members invite are your level 2 members, and the people your level 2 members invite are your level 3 members. You can get invitation rewards for up to three-level members to activate their accounts.",
  },
];

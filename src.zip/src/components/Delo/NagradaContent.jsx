export const NagradaItems = [
  {
    title: "PRIMER 1",
    text: "Osebe, ki jih povabite, so vaši člani na ravni 1, osebe, ki jih povabijo vaši člani na ravni 1, so vaši člani na ravni 2, osebe, ki jih povabijo vaši člani na ravni 2, pa so vaši člani na ravni 3. Prejmete lahko nagrade za povabila za člane do treh ravni, da aktivirate njihove račune.",
  },
  {
    title: "PRIMER 2",
    text: "Vaš račun je račun na ravni LV2. Povabili ste prijatelja A, da aktivira račun ravni LV2. Kot nagrado za povabilo lahko prejmete 40,8 USDT in prijatelj A bo postal vaš član 1. stopnje. Ko vaš član na ravni 1 povabi prijatelja B, da aktivira račun na ravni LV2, lahko prejmete nagrado za povabilo v višini 27,2 USDT in prijatelj B bo postal vaš član na ravni 2. Ko vaš član 2. stopnje povabi prijatelja C, da aktivira račun LV2, lahko prejmete 13,6 USDT nagrade za povabilo in prijatelj C bo postal vaš član 3. stopnje. Prejmete lahko nagrade za povabilo za člane do treh ravni, da aktivirajo svoje račune. Več ljudi kot povabite ali več ljudi kot povabijo vaši člani 1. in 2. stopnje, več nagrad za povabilo boste prejeli, neomejeno.",
  },
  {
    title: "PRIMER 3",
    text: "Prejemniki nagrad za povabila ne morejo prejeti nagrad za povabila, ki presegajo njihovo raven LV. (Primer: Vi ste LV1 in oseba, ki jo povabite, je aktivirala LV2, dobite lahko le nagrado za povabilo LV1).",
  },
  {
    title: "PRIMER 4",
    text: "Osebe, ki jih povabite, so vaši člani na ravni 1, osebe, ki jih povabijo vaši člani na ravni 1, so vaši člani na ravni 2, osebe, ki jih povabijo vaši člani na ravni 2, pa so vaši člani na ravni 3. Prejmete lahko nagrade za povabila za člane do treh ravni, da aktivirate njihove račune.",
  },
];

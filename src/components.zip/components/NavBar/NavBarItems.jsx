export const NavMenuItems = [
  {
    title: "Domov",
    url: "/",
    cName: "nav-links",
  },
  {
    title: "Delo",
    url: "/delo",
    cName: "nav-links",
  },
  {
    title: "Pomoc",
    url: "/pomoc",
    cName: "nav-links",
  },
  {
    title: "Akcije",
    url: "/akcije",
    cName: "nav-links",
  },
  {
    title: "Kontakt",
    url: "/kontakt",
    cName: "nav-links",
  },
];

import React from 'react'
import "./Content.css"

export default function Content() {
  return (
    <div>Content</div>
  )
}
